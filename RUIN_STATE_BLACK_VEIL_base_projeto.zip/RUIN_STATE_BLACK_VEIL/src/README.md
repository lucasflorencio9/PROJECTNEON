# Código-fonte

Os módulos de gameplay serão adicionados por etapas depois de validar o ambiente PVSnesLib. Não há código de jogo completo nesta pasta ainda. Evite criar arquivos vazios que pareçam funcionalidades prontas; cada módulo deve ser implementado, compilado e testado antes de ser marcado como concluído.
