# RUIN//STATE: BLACK VEIL

Projeto de um Metroidvania 2D para Super Nintendo (SNES), desenvolvido em C com PVSnesLib.

## Identidade do projeto
- Franquia: RUIN//STATE
- Jogo: RUIN//STATE: BLACK VEIL
- Protagonista: No One — um ciborgue com poucas lembranças do passado
- Antagonista central: facção criminosa BLACK VEIL
- Cenário: Nova Aurora, 2149
- Estilo: pixel art detalhada inspirada nos jogos de SNES
- Dificuldade: equilibrada
- Narrativa: cinematográfica usando cenas, sprites, diálogos e eventos no próprio jogo
- Salvamento: salas de salvamento e checkpoints persistentes
- Plataforma final pretendida: ROM `.sfc`

## Estado real deste pacote
Este é o **esqueleto de projeto e documentação**, não uma ROM pronta. Os módulos de gameplay estão planejados, mas precisam ser implementados e testados. A compilação depende de configurar a PVSnesLib e validar o ambiente.

## Documentação
- `docs/game_design.md` — visão do jogo
- `docs/architecture.md` — arquitetura técnica
- `docs/map_progression.md` — regiões e progressão
- `docs/story_and_characters.md` — narrativa
- `docs/build_and_test.md` — plano de compilação e testes

## Próximo passo
Configurar um ambiente Linux em nuvem com a toolchain PVSnesLib, compilar um exemplo mínimo e validar a geração de uma ROM antes de desenvolver os sistemas de gameplay.
