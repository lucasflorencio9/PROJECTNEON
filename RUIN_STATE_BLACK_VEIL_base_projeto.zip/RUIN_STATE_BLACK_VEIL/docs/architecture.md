# Arquitetura técnica

## Tecnologia
C + PVSnesLib. A escolha final de bibliotecas, formatos de assets e configurações de memória deve ser confirmada usando a versão concreta da toolchain instalada.

## Módulos previstos
- `main.c`: inicialização e loop principal.
- `game_state.c`: menu, gameplay, pausa, cenas, morte e transições.
- `player.c` / `physics.c`: movimento, salto, gravidade, dano e estados do personagem.
- `combat.c` / `weapons.c`: ataques, projéteis, munição, energia e dano.
- `enemies.c` / `bosses.c`: lógica de inimigos e chefes.
- `rooms.c` / `collision.c` / `camera.c`: salas, colisões, portas, transições e câmera.
- `abilities.c` / `inventory.c`: upgrades, itens e requisitos de acesso.
- `save_system.c`: formato e validação dos dados persistentes em SRAM.
- `dialogue.c` / `cutscenes.c`: diálogos e cenas montadas com recursos do jogo.
- `hud.c` / `audio.c`: interface e áudio.

## Princípios
1. Separar estado do jogo de renderização.
2. Usar identificadores estáveis para salas, itens, chefes e flags.
3. Manter mapas e requisitos orientados a dados sempre que isso for viável na toolchain.
4. Limitar alocações dinâmicas; preferir estruturas estáticas adequadas ao hardware.
5. Planejar explicitamente memória de trabalho, VRAM, CGRAM, OAM, SRAM e tamanho de ROM.
6. Fazer builds frequentes; não esperar até o fim para compilar.
7. Confirmar limites reais do SNES e da PVSnesLib em vez de presumir que recursos de PC estão disponíveis.

## Salvamento
Estrutura versionada com assinatura/magic, versão, região/sala, estado de upgrades, chefes e eventos permanentes, além de validação simples. Tamanho, checksum e detalhes de escrita serão definidos depois de verificar as APIs da versão da PVSnesLib utilizada.

## Observação
Os nomes de módulos neste pacote representam a arquitetura planejada. Ainda não significam que esses sistemas estejam implementados.
