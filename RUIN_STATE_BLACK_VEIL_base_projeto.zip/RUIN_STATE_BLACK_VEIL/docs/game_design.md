# Documento de design — RUIN//STATE: BLACK VEIL

## Visão
Metroidvania 2D para SNES, com exploração interconectada, combate, habilidades que abrem novas rotas, chefes, segredos e salvamento persistente.

## Pilares
1. Exploração interconectada: regiões conectadas por portas, elevadores, atalhos e passagens secretas.
2. Progressão por habilidades: equipamentos mudam tanto o combate quanto o acesso ao mapa.
3. Combate legível: inimigos com padrões reconhecíveis e chefes com fases ou ataques distintos.
4. Narrativa ambiental e cinematográfica: cenas curtas, diálogos, documentos e eventos de cenário.
5. Consequências: a BLACK VEIL é uma organização criminosa com hierarquia, logística e instalações; não apenas um conjunto aleatório de inimigos.

## Escopo de referência
- 5 regiões principais.
- Meta de planejamento inicial: aproximadamente 80–100 salas, sujeita a validação de memória, arte e esforço.
- 6 chefes principais como meta inicial.
- 6–8 habilidades de exploração como meta inicial.
- Campanha com início, desenvolvimento e encerramento próprios.

Esses números são metas de produção, não conteúdo já implementado. A escala será ajustada após protótipos reais e medições no SNES.

## Controles propostos
- Direcional: mover/navegar
- A: pular
- B: ataque corpo a corpo
- Y: arma principal
- X: habilidade cibernética
- L/R: trocar equipamento
- Start: pausa
- Select: mapa/status

A configuração final depende de testes de usabilidade e do layout de controles no emulador.

## Regras de qualidade
- Não chamar uma build de “jogo completo” antes de testar a campanha inteira.
- Toda habilidade de progressão deve ter pelo menos uma utilização clara no mapa.
- Todo item único e chefe derrotado deve atualizar o estado de progressão.
- A morte e o carregamento de salvamento não podem bloquear o progresso.
