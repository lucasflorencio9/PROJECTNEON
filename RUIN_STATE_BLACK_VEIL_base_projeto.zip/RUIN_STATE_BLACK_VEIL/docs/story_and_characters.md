# História e personagens

## Cenário
Nova Aurora, 2149. Implantes cibernéticos são comuns entre alguns grupos, enquanto humanos artificiais conseguem reproduzir aparência, voz e comportamento humanos com precisão quase perfeita.

## Protagonista: No One
No One é um ciborgue com poucas lembranças de seu passado. “No One” é como é conhecido; não é necessário revelar seu nome verdadeiro no primeiro jogo. A origem das modificações e algumas memórias serão elementos secundários e graduais, sem tirar o foco do conflito principal.

## Antagonista: BLACK VEIL
Organização criminosa com ramificações em contrabando, tráfico de armas, drogas sintéticas, implantes ilegais, exploração humana, experimentos clandestinos e corrupção. A organização terá hierarquia e instalações identificáveis, com comandantes e chefes ligados às suas operações.

## Estrutura narrativa
1. **Descoberta:** No One cruza uma operação da BLACK VEIL no Setor Baixo.
2. **Investigação:** descobre rotas, registros e instalações clandestinas.
3. **Escalada:** a facção passa a caçá-lo e envia unidades especializadas.
4. **Infiltração:** invade setores protegidos e derrota comandantes.
5. **Confronto:** atinge o núcleo operacional da BLACK VEIL e encerra o conflito principal.

## Tom
Sombrio, adulto e cyberpunk. Violência, corrupção e exploração terão consequências narrativas; a atmosfera será construída com cenários, diálogos, documentos e cenas curtas.

## Continuidade da trilogia
O primeiro jogo deve ter um arco completo contra a BLACK VEIL. O mistério sobre humanos artificiais e sobre o passado de No One pode preparar histórias futuras, mas não deve deixar o conflito principal sem conclusão.
