# Mapa e progressão

## Regiões
1. **Setor Baixo** — começo, mercado ilegal, esconderijos e primeiras operações da BLACK VEIL.
2. **Linha Fantasma** — metrô abandonado, túneis, transporte de contrabando e sistemas elétricos.
3. **Laboratório Prisma** — experimentação clandestina e produção de humanos artificiais.
4. **Torre NEXUS** — instalações corporativas, segurança reforçada e centro de operações.
5. **Núcleo Zero** — instalação final e conclusão do conflito principal.

## Progressão por habilidade
- Disparo de impacto: rompe barreiras específicas.
- Impulso cibernético: alcança plataformas e vãos maiores.
- Sobrecarga: ativa mecanismos energizados.
- Blindagem térmica: atravessa zonas de calor.
- Módulo de fase: atravessa certos campos de segurança.
- Núcleo de combate: aprimora capacidades ofensivas.

Esses nomes e habilidades são propostas iniciais. Cada habilidade deve ser testada no controle e no mapa antes de ser considerada definitiva.

## Dados por sala
Cada sala deve definir, conforme o sistema final:
- ID único e região
- conexões/portas
- tiles e colisões
- pontos de entrada e saída
- inimigos e itens
- eventos e requisitos
- pontos de salvamento ou checkpoints
- câmera e limites de rolagem

## Critérios de progressão
- Portas bloqueadas mostram feedback compreensível.
- Habilidades necessárias são adquiridas antes de qualquer bloqueio obrigatório.
- Deve existir rota de retorno para salas importantes.
- Itens únicos não reaparecem indevidamente depois de carregar um save.
- A campanha principal deve poder ser concluída sem itens opcionais.
