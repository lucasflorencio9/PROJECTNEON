# Compilação e testes

## Importante
Este repositório ainda não contém uma ROM compilada. Primeiro é preciso configurar e validar uma versão concreta da PVSnesLib.

## Fluxo de compilação
1. Abrir o repositório no GitHub Codespaces ou ambiente Linux compatível.
2. Instalar/configurar a toolchain seguindo a documentação oficial da PVSnesLib.
3. Compilar um exemplo oficial mínimo.
4. Confirmar que o arquivo ROM foi gerado e abre no emulador.
5. Só então integrar o código do jogo, módulo por módulo.
6. Guardar logs de compilação e corrigir warnings/erros antes de avançar.

## Testes mínimos por etapa
- Build: compila sem erros e produz ROM válida.
- Controle: cada botão gera a ação esperada.
- Movimento: limites, salto, colisões e quedas.
- Combate: dano, invulnerabilidade temporária, morte de inimigos e chefes.
- Mapa: portas, conexões, câmera e retorno.
- Progressão: itens liberam as rotas corretas.
- Salvamento: gravar, reiniciar, carregar e validar estado.
- Campanha: não há bloqueios obrigatórios impossíveis de atravessar.
- Desempenho: atualização estável e sem exceder recursos gráficos.
- Compatibilidade: testar em pelo menos um emulador SNES confiável no Android e, se possível, em outro emulador.

## Fontes oficiais para começar
- PVSnesLib: https://github.com/alekmaul/pvsneslib
- Instalação: https://github.com/alekmaul/pvsneslib/wiki/Installation
- Exemplo de compilação: https://github.com/alekmaul/pvsneslib/wiki/Compiling-helloworld-example

## ROM final
A extensão pretendida é `.sfc`. Só chamar de versão final depois de jogar e testar a campanha, não apenas após compilar.
