# Assets

Organização planejada:
- `tiles/`: tilesets de cenários
- `sprites/`: personagem, inimigos, chefes e animações
- `backgrounds/`: fundos e camadas de cenário
- `maps/`: mapas e dados de salas
- `palettes/`: paletas SNES
- `music/`: música
- `sfx/`: efeitos sonoros

As artes de referência conceituais não são assets finais. Os arquivos gráficos precisarão ser convertidos para formatos compatíveis com a toolchain PVSnesLib.
